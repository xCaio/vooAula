import 'passageiro.dart';
import 'voo.dart';

class Passagem{
  int? numero;
  int? poltrona;
  String? voo;
  DateTime hora = DateTime.now();
  late Passageiro passageiro; 
  late Voo passageiros;

  Passagem(this.numero, this.poltrona, this.voo);

  @override
  String toString(){
    return "\u{1F6EB} [Nº $numero - Poltrona $poltrona - ${hora.hour}";
  }

  void atribuirPassageiro(Passageiro passageiro){
    this.passageiro = passageiro;
    print("Venda Realizada");
  }
  
  void cadastraPassagens(Passagem passagem){
    passageiros.add(passagem);
    print("Passageiro cadastrado");
  }


}