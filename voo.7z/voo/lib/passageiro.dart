import 'passagem.dart';
class Passageiro{
  String cpf= "";
  String nome = "";
  String end = "";
  String tel = "";

  Passageiro(cpf, nome, end, tel){
    this.cpf = cpf;
    this.nome = nome;
    this.end = end;
    this.tel = tel;

  }
}