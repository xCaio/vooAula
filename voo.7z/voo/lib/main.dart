import 'passageiro.dart';
import 'passagem.dart';

void main(List<String> args) {
  Passageiro passageiro = new Passageiro("123.456.789-10", "Caio", "R. das chacaras", "31-9-8216-6031");
  Passagem passagem = new Passagem(2, 2, "BH");
  print(passagem.voo);
  print(passagem.numero);
  print(passagem.poltrona);

  passagem.atribuirPassageiro(passageiro);
  

}
