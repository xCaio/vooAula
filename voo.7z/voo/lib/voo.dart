import 'passagem.dart';

class Voo{
  String? aviao;
  String? destino;
  List<String> passageiros =[];

  void add(Passagem passagem) {}
}